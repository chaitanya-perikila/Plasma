let map;

function initMap() {
    map = new google.maps.Map(document.getElementById("map"), {

        center: { lat: 16.5062, lng: 80.6480 },
        zoom: 8,
    });
}

